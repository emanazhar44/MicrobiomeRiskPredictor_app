
import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
import joblib
import os

# Load data
df = pd.read_csv("sample_data.csv")
X = df.drop(columns=["label"])
y = df["label"]

# Train model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = MLPClassifier(hidden_layer_sizes=(50, 25), max_iter=1000, random_state=42)
model.fit(X_train, y_train)
acc = accuracy_score(y_test, model.predict(X_test))

# Save model
joblib.dump(model, "mlp_model.pkl")

# Streamlit App
st.title("🧬 Microbiome Disease Predictor (Streamlit)")
st.write(f"Model Accuracy: {acc*100:.2f}%")

option = st.radio("Choose Input Type", ["Manual Entry", "Upload CSV"])

if option == "Manual Entry":
    inputs = {}
    for col in X.columns:
        inputs[col] = st.slider(col, 0.0, 1.0, 0.5, 0.01)

    if st.button("Predict"):
        input_df = pd.DataFrame([inputs])
        pred = model.predict(input_df)[0]
        st.success("Prediction: Diseased" if pred == 1 else "Prediction: Healthy")

else:
    uploaded_file = st.file_uploader("Upload CSV", type="csv")
    if uploaded_file:
        input_df = pd.read_csv(uploaded_file)
        if 'label' in input_df.columns:
            input_df = input_df.drop(columns=['label'])
        preds = model.predict(input_df)
        input_df["Prediction"] = ["Diseased" if p == 1 else "Healthy" for p in preds]
        st.dataframe(input_df)
        st.download_button("Download Predictions", input_df.to_csv(index=False), file_name="predictions.csv")
