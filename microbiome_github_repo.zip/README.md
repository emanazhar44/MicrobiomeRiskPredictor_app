
# 🧬 Microbiome-Based Disease Predictor App

This is a machine learning app for predicting disease status from microbiome data. It includes:

- Manual and batch input (CSV)
- Deep learning model (MLPClassifier)
- Real-time predictions
- Gradio and Streamlit interfaces
- Ready to deploy on Hugging Face Spaces or Streamlit Cloud
- Sample dataset and visualizations

## 🔬 Sample Features

- Bacteroides
- Firmicutes
- Actinobacteria
- Proteobacteria
- Lactobacillus
- Prevotella

## 🚀 Deployment Instructions

### Hugging Face (Gradio)
1. Go to [Hugging Face Spaces](https://huggingface.co/spaces)
2. Create a Gradio Space
3. Upload:
   - `app.py`
   - `requirements.txt`
   - `sample_data.csv`

### Streamlit Cloud
1. Create a GitHub repo with the files
2. Go to [Streamlit Cloud](https://streamlit.io/cloud)
3. Connect the repo and deploy

## 📊 Example Output

- Health status prediction (Healthy / Diseased)
- Downloadable CSV of batch predictions
- Accuracy display

## 📈 To-Do (Extendable Features)

- SHAP-based feature explanations
- PDF report generation
- Visualization with Seaborn / Matplotlib
