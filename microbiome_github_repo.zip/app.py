
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
import gradio as gr

# Load sample dataset
data = pd.read_csv("sample_data.csv")
X = data.drop(columns=["label"])
y = data["label"]

# Train an MLP model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = MLPClassifier(hidden_layer_sizes=(50, 25), max_iter=1000, random_state=42)
model.fit(X_train, y_train)
acc = accuracy_score(y_test, model.predict(X_test))

# Function for single prediction
def predict_single(**kwargs):
    input_df = pd.DataFrame([kwargs])
    prediction = model.predict(input_df)[0]
    return "Diseased" if prediction == 1 else "Healthy"

# Function for batch prediction
def predict_batch(file):
    df = pd.read_csv(file.name)
    if "label" in df.columns:
        df = df.drop(columns=["label"])
    preds = model.predict(df)
    df["Prediction"] = ["Diseased" if p == 1 else "Healthy" for p in preds]
    df.to_csv("predictions.csv", index=False)
    return "predictions.csv"

# Create input sliders
sliders = [
    gr.Slider(0, 1, step=0.01, label=col) for col in X.columns
]

# Define tabs
single_tab = gr.Interface(fn=predict_single, inputs=sliders, outputs="text",
                          title="🧬 Microbiome Disease Predictor",
                          description=f"Model Accuracy: {acc*100:.2f}%. Predict from individual features.")

batch_tab = gr.Interface(fn=predict_batch, inputs=gr.File(), outputs=gr.File(),
                         title="📂 Batch Prediction", description="Upload CSV of microbiome data to get predictions.")

# Launch app
gr.TabbedInterface([single_tab, batch_tab], ["Single Sample", "Batch Upload"]).launch()
